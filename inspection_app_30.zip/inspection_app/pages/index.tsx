import Link from 'next/link';
import Head from 'next/head';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/router';
import type { InspectionSummary } from '@/lib/types';
import { InspectionCard } from '@/components/InspectionCard';

interface MeUser { userId: string; email: string; name: string; }

type StatusFilter = 'all' | 'scheduled' | 'in_progress' | 'completed' | 'cancelled';

export default function Home() {
  const router = useRouter();
  const [hasLogo, setHasLogo] = useState(false);
  const [me, setMe] = useState<MeUser | null>(null);

  const [inspections, setInspections] = useState<InspectionSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  // Sort by scheduled_date (falls back to completedAt, then createdAt).
  // 'desc' = newest first (default), 'asc' = oldest first.
  const [sortDir, setSortDir] = useState<'desc' | 'asc'>('desc');
  // Filter by inspector name. 'all' = no filter; otherwise match by name (case-insensitive).
  const [inspectorFilter, setInspectorFilter] = useState<string>('all');
  // Filter by template internal name. 'all' = no filter.
  const [templateFilter, setTemplateFilter] = useState<string>('all');

  useEffect(() => {
    const img = new window.Image();
    img.onload = () => setHasLogo(true);
    img.onerror = () => setHasLogo(false);
    img.src = '/logo.png';
  }, []);

  useEffect(() => {
    fetch('/api/auth/me')
      .then((r) => r.json())
      .then((data) => { if (data.authenticated) setMe(data.user); })
      .catch(() => {});
  }, []);

  // Wrapped in useCallback so we can call it from multiple places.
  const fetchInspections = useCallback(async () => {
    try {
      const r = await fetch('/api/inspections', { cache: 'no-store' });
      const data = await r.json();
      if (data.error) {
        setError(data.error);
      } else {
        setInspections(data.inspections || []);
        setError(null);
      }
    } catch (e: any) {
      setError(String(e.message || e));
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial load AND honor the "just_*" query hints by doing a delayed second
  // fetch (HubSpot search index can lag for fresh creates).
  // This effect runs ONCE on mount. router.query is read directly inside without
  // a dependency to prevent re-running when the query changes.
  useEffect(() => {
    fetchInspections();
    // Check if we arrived with a "just_" hint indicating a fresh record was created
    const url = typeof window !== 'undefined' ? window.location.search : '';
    if (url.includes('just_')) {
      const t = setTimeout(fetchInspections, 1800);
      return () => clearTimeout(t);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Re-fetch when the user returns to this tab (mobile app switching, alt-tab on desktop)
  useEffect(() => {
    function onFocus() {
      fetchInspections();
    }
    window.addEventListener('focus', onFocus);
    return () => {
      window.removeEventListener('focus', onFocus);
    };
  }, [fetchInspections]);

  async function handleLogout() {
    try { await fetch('/api/auth/logout', { method: 'POST' }); } catch {}
    router.replace('/login');
  }

  // Apply search + status + inspector + template filters to the inspection list
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const wantStatus = statusFilter;
    const wantInspector = inspectorFilter; // 'all' or lowercase inspector name
    const wantTemplate = templateFilter; // 'all' or template internal name
    return inspections.filter((i) => {
      // Search filter (matches against property address)
      if (q && !i.propertyAddressSnapshot.toLowerCase().includes(q)) return false;
      // Status filter
      if (wantStatus !== 'all') {
        const s = (i.status || '').trim().toLowerCase();
        if (wantStatus === 'scheduled' && s !== 'scheduled') return false;
        if (wantStatus === 'in_progress' && !(s === 'in progress' || s === 'in-progress' || s === 'in_progress')) return false;
        if (wantStatus === 'completed' && !(s === 'completed' || s === 'complete' || s === 'submitted')) return false;
        if (wantStatus === 'cancelled' && !(s === 'cancelled' || s === 'canceled')) return false;
      }
      // Inspector filter (case-insensitive name match)
      if (wantInspector !== 'all') {
        if ((i.inspectorName || '').trim().toLowerCase() !== wantInspector) return false;
      }
      // Template filter (exact match on internal name)
      if (wantTemplate !== 'all') {
        if ((i.templateType || '') !== wantTemplate) return false;
      }
      return true;
    });
  }, [inspections, search, statusFilter, inspectorFilter, templateFilter]);

  // Apply sort. Priority: scheduled_date > completed_at > created_at.
  // Inspections with no date sort to the end (regardless of asc/desc).
  // HubSpot Date fields come back as epoch-ms strings; DateTime/ISO fields come
  // back as ISO 8601. Parse both forms.
  const sorted = useMemo(() => {
    const effective = (i: InspectionSummary): number | null => {
      const raw = i.scheduledDate || i.completedAt || i.createdAt;
      if (!raw) return null;
      if (/^\d+$/.test(raw)) {
        const n = Number(raw);
        return isNaN(n) ? null : n;
      }
      const t = Date.parse(raw);
      return isNaN(t) ? null : t;
    };
    const copy = [...filtered];
    copy.sort((a, b) => {
      const ta = effective(a);
      const tb = effective(b);
      // Missing dates always sort to the end
      if (ta == null && tb == null) return 0;
      if (ta == null) return 1;
      if (tb == null) return -1;
      return sortDir === 'desc' ? tb - ta : ta - tb;
    });
    return copy;
  }, [filtered, sortDir]);

  // Count by status for filter chips
  const counts = useMemo(() => {
    const c = { all: inspections.length, scheduled: 0, in_progress: 0, completed: 0, cancelled: 0 };
    for (const i of inspections) {
      const s = (i.status || '').trim().toLowerCase();
      if (s === 'scheduled') c.scheduled++;
      else if (s === 'in progress' || s === 'in-progress' || s === 'in_progress') c.in_progress++;
      else if (s === 'completed' || s === 'complete' || s === 'submitted') c.completed++;
      else if (s === 'cancelled' || s === 'canceled') c.cancelled++;
    }
    return c;
  }, [inspections]);

  // Derive inspector dropdown options from the loaded inspections.
  // Each option: { value: lowercase name (filter key), label: original-case display name, count }
  // Dedupes case-insensitively; uses the first variant seen for display.
  const inspectorOptions = useMemo(() => {
    const map = new Map<string, { label: string; count: number }>();
    for (const i of inspections) {
      const raw = (i.inspectorName || '').trim();
      if (!raw) continue;
      const key = raw.toLowerCase();
      const existing = map.get(key);
      if (existing) existing.count++;
      else map.set(key, { label: raw, count: 1 });
    }
    return Array.from(map.entries())
      .map(([value, { label, count }]) => ({ value, label, count }))
      .sort((a, b) => a.label.localeCompare(b.label));
  }, [inspections]);

  // Derive template dropdown options. Templates are stable internal names, but
  // we'll only show those that appear in the loaded data so the filter is meaningful.
  const templateOptions = useMemo(() => {
    const map = new Map<string, number>();
    for (const i of inspections) {
      const t = (i.templateType || '').trim();
      if (!t) continue;
      map.set(t, (map.get(t) || 0) + 1);
    }
    return Array.from(map.entries())
      .map(([value, count]) => ({ value, label: prettyTemplateLabel(value), count }))
      .sort((a, b) => a.label.localeCompare(b.label));
  }, [inspections]);

  return (
    <>
      <Head>
        <title>ResiHome Inspection</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
      </Head>
      <main className="min-h-screen bg-gray-50">
        {/* Pink branded header */}
        <header className="bg-brand text-white">
          <div className="max-w-3xl mx-auto px-4 pt-4 pb-5">
            <div className="flex items-center justify-between gap-3 mb-3">
              <div className="flex items-center gap-3 min-w-0">
                {hasLogo ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src="/logo.png"
                    alt="ResiHome"
                    className="h-10 w-10 object-contain rounded-lg bg-white p-1 shadow"
                  />
                ) : (
                  <div className="h-10 w-10 flex items-center justify-center bg-white text-brand rounded-lg font-heading font-extrabold">
                    RH
                  </div>
                )}
                <div className="min-w-0">
                  <h1 className="font-heading font-extrabold text-lg tracking-tight">
                    ResiHome Inspections
                  </h1>
                  {me && (
                    <div className="text-xs text-white/80 truncate">Welcome, {me.name}</div>
                  )}
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="text-xs font-heading font-semibold text-white/90 hover:text-white whitespace-nowrap"
              >
                Sign Out
              </button>
            </div>

            {/* + New Inspection button */}
            <Link
              href="/inspection/new"
              className="flex items-center gap-3 bg-pink-100 hover:bg-pink-200 rounded-xl px-4 py-3 transition active:scale-[0.99] shadow-md"
            >
              <div className="w-9 h-9 bg-brand rounded-lg flex items-center justify-center shrink-0">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                  <line x1="12" y1="5" x2="12" y2="19" />
                  <line x1="5" y1="12" x2="19" y2="12" />
                </svg>
              </div>
              <span className="font-heading font-bold text-base text-brand">New Inspection</span>
            </Link>
          </div>
        </header>

        {/* Search + Filters */}
        <div className="max-w-3xl mx-auto px-4 pt-4 pb-2">
          <div className="relative mb-3">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                 strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
                 className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input
              type="text"
              placeholder="Search by address..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="focus-brand w-full pl-9 pr-3 py-2.5 text-sm border border-gray-300 rounded-lg bg-white"
            />
          </div>

          {/* Filter chips */}
          <div className="flex flex-wrap gap-1.5 mb-3">
            <FilterChip label={`All (${counts.all})`} active={statusFilter === 'all'} onClick={() => setStatusFilter('all')} />
            <FilterChip label={`Scheduled (${counts.scheduled})`} active={statusFilter === 'scheduled'} onClick={() => setStatusFilter('scheduled')} />
            <FilterChip label={`In Progress (${counts.in_progress})`} active={statusFilter === 'in_progress'} onClick={() => setStatusFilter('in_progress')} />
            <FilterChip label={`Completed (${counts.completed})`} active={statusFilter === 'completed'} onClick={() => setStatusFilter('completed')} />
            {counts.cancelled > 0 && (
              <FilterChip label={`Cancelled (${counts.cancelled})`} active={statusFilter === 'cancelled'} onClick={() => setStatusFilter('cancelled')} />
            )}
          </div>

          {/* Filter controls row: inspector dropdown | template dropdown | date sort */}
          <div className="flex items-center gap-2 mb-2 overflow-x-auto pb-1 -mx-1 px-1">
            {/* Inspector filter */}
            <div className="relative shrink-0">
              <select
                value={inspectorFilter}
                onChange={(e) => setInspectorFilter(e.target.value)}
                className={`appearance-none text-xs font-heading font-semibold pl-3 pr-7 py-1.5 border rounded-md bg-white cursor-pointer whitespace-nowrap ${
                  inspectorFilter !== 'all'
                    ? 'border-brand text-brand'
                    : 'border-gray-300 text-gray-700 hover:border-brand/50'
                }`}
                title="Filter by inspector"
              >
                <option value="all">All Inspectors</option>
                {inspectorOptions.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label} ({opt.count})
                  </option>
                ))}
              </select>
              <svg
                className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500"
                width="10" height="10" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
              >
                <polyline points="6 9 12 15 18 9" />
              </svg>
            </div>

            {/* Template filter */}
            <div className="relative shrink-0">
              <select
                value={templateFilter}
                onChange={(e) => setTemplateFilter(e.target.value)}
                className={`appearance-none text-xs font-heading font-semibold pl-3 pr-7 py-1.5 border rounded-md bg-white cursor-pointer whitespace-nowrap ${
                  templateFilter !== 'all'
                    ? 'border-brand text-brand'
                    : 'border-gray-300 text-gray-700 hover:border-brand/50'
                }`}
                title="Filter by template"
              >
                <option value="all">All Templates</option>
                {templateOptions.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label} ({opt.count})
                  </option>
                ))}
              </select>
              <svg
                className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500"
                width="10" height="10" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
              >
                <polyline points="6 9 12 15 18 9" />
              </svg>
            </div>

            {/* Date sort toggle */}
            <button
              type="button"
              onClick={() => setSortDir(sortDir === 'desc' ? 'asc' : 'desc')}
              className="shrink-0 inline-flex items-center gap-1 text-xs font-heading font-semibold text-gray-700 hover:text-brand px-2 py-1.5 border border-gray-300 rounded-md bg-white whitespace-nowrap"
              title={sortDir === 'desc' ? 'Showing newest first. Tap to flip to oldest first.' : 'Showing oldest first. Tap to flip to newest first.'}
            >
              <span>Date</span>
              {sortDir === 'desc' ? (
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="12" y1="5" x2="12" y2="19" />
                  <polyline points="19 12 12 19 5 12" />
                </svg>
              ) : (
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                     strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="12" y1="19" x2="12" y2="5" />
                  <polyline points="5 12 12 5 19 12" />
                </svg>
              )}
            </button>

            {/* Clear-all link, only shown when any filter is active */}
            {(inspectorFilter !== 'all' || templateFilter !== 'all') && (
              <button
                type="button"
                onClick={() => { setInspectorFilter('all'); setTemplateFilter('all'); }}
                className="shrink-0 text-xs text-gray-500 hover:text-brand font-heading underline whitespace-nowrap"
                title="Clear inspector and template filters"
              >
                Clear
              </button>
            )}
          </div>

          <div className="text-xs text-gray-500 font-heading mb-3">
            {loading ? 'Loading...' : `${sorted.length} of ${inspections.length} inspection${inspections.length === 1 ? '' : 's'}`}
          </div>
        </div>

        {/* Inspection list */}
        <div className="max-w-3xl mx-auto px-4 pb-12">
          {loading && (
            <div className="text-sm text-gray-500 text-center py-8">Loading inspections...</div>
          )}
          {error && !loading && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-sm text-red-700 mb-3">
              Could not load inspections: {error}
            </div>
          )}
          {!loading && !error && sorted.length === 0 && (
            <div className="text-center py-12">
              <div className="text-sm text-gray-500 mb-2">
                {inspections.length === 0 ? 'No inspections yet.' : 'No matching inspections.'}
              </div>
              {inspections.length === 0 && (
                <div className="text-xs text-gray-400">
                  Tap &quot;+ New Inspection&quot; above to get started.
                </div>
              )}
            </div>
          )}
          {sorted.map((i) => (
            <InspectionCard key={i.recordId} inspection={i} />
          ))}
        </div>
      </main>
    </>
  );
}

interface ChipProps {
  label: string;
  active: boolean;
  onClick: () => void;
}

function FilterChip({ label, active, onClick }: ChipProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`text-xs font-heading font-semibold px-3 py-1.5 rounded-full border transition whitespace-nowrap ${
        active
          ? 'bg-brand text-white border-brand'
          : 'bg-white text-ink border-gray-300 hover:border-brand/50'
      }`}
    >
      {label}
    </button>
  );
}

// Display label for a template internal name.
// "pm_scope_inspection" -> "Scope"
// "qc_new_construction_rrqc" -> "QC New Construction"
function prettyTemplateLabel(t: string): string {
  if (!t) return '';
  return t
    .replace(/^pm_/, '')
    .replace(/^qc_/, 'QC ')
    .replace(/_inspection$/, '')
    .replace(/_/g, ' ')
    .split(' ')
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
}

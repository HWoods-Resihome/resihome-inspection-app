import type { NextApiRequest, NextApiResponse } from 'next';
import {
  upsertAnswers,
  archiveAnswers,
  updateInspection,
  fetchInspectionById,
  type AnswerUpsert,
} from '@/lib/hubspot';
import { getSessionFromRequest } from '@/lib/auth';

export const config = {
  api: { bodyParser: { sizeLimit: '5mb' } },
};

interface BodyShape {
  upserts: AnswerUpsert[];
  archives?: string[];
  bumpStatusToInProgress?: boolean;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }
  const session = await getSessionFromRequest(req);
  if (!session) return res.status(401).json({ error: 'Not authenticated' });

  const { id } = req.query;
  if (!id || typeof id !== 'string') {
    return res.status(400).json({ error: 'Missing inspection id' });
  }

  try {
    const body = req.body as BodyShape;
    const upserts = body?.upserts || [];
    const archives = body?.archives || [];

    const t0 = Date.now();

    // Server-side status transition: if this is the FIRST edit and the
    // inspection is still Scheduled, flip it to In Progress.
    if (body.bumpStatusToInProgress) {
      const insp = await fetchInspectionById(id);
      if (insp && (insp.status || '').toLowerCase() === 'scheduled') {
        await updateInspection(id, {
          status: 'in_progress',
          started_at: new Date().toISOString(),
        });
      }
    }

    const upsertResults = await upsertAnswers(id, upserts);
    if (archives.length > 0) {
      await archiveAnswers(archives);
    }

    const elapsed = Date.now() - t0;
    if (elapsed > 5000) {
      console.warn(`[answers] slow autosave: ${elapsed}ms, upserts=${upserts.length}, archives=${archives.length}`);
    }

    return res.status(200).json({ success: true, results: upsertResults, elapsedMs: elapsed });
  } catch (e: any) {
    console.error(`POST /api/inspections/${id}/answers failed:`, e);
    return res.status(500).json({ error: String(e.message || e) });
  }
}
